#include <iostream>
#include <vector>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"


#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif




const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;
const int NUM_SEGMENTS = 36; // Number of segments used to draw the cylinder


// Vertex shader source code
const char* vertexShaderSource = R"(
    #version 330 core
    layout (location = 0) in vec3 aPos;
    layout (location = 1) in vec2 aTexCoord;
    layout (location = 2) in vec3 aNormal; // Normal vector

    out vec2 TexCoord;
    out vec3 Normal; // Normal output to fragment shader
    out vec3 FragPos; // Fragment position output to fragment shader

    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main() {
        FragPos = vec3(model * vec4(aPos, 1.0)); // Calculate fragment position
        Normal = mat3(transpose(inverse(model))) * aNormal; // Transform normals

        gl_Position = projection * view * model * vec4(aPos, 1.0f);
        TexCoord = aTexCoord;
    }
)";


// Fragment shader source code
const char* fragmentShaderSource = R"(
    #version 330 core
    out vec4 FragColor;

    in vec2 TexCoord;
    in vec3 Normal; // Received normal
    in vec3 FragPos; // Received fragment position

    uniform sampler2D texture1;
    uniform vec3 lightPos1; // First light source position
    uniform vec3 lightColor1; // First light color
    uniform vec3 lightPos2; // Second light source position
    uniform vec3 lightColor2; // Second light color
    uniform vec3 viewPos; // Camera/view position
    uniform vec3 objectColor; // Object color
    uniform float reflectivity; // Reflectivity strength

    // Function to calculate lighting
    vec3 CalculateLight(vec3 lightPos, vec3 lightColor, vec3 norm, vec3 FragPos, vec3 viewPos) {
        vec3 lightDir = normalize(lightPos - FragPos);
        float diff = max(dot(norm, lightDir), 0.0);
        vec3 diffuse = diff * lightColor;

        float specularStrength = 0.5;
        vec3 viewDir = normalize(viewPos - FragPos);
        vec3 reflectDir = reflect(-lightDir, norm);
        float spec = pow(max(dot(viewDir, reflectDir), 0.0), 32);
        vec3 specular = specularStrength * spec * lightColor;  

        return diffuse + specular;
    }

    void main() {
        // Ambient component
        float ambientStrength = 0.5;
        vec3 ambient = ambientStrength * (lightColor1 + lightColor2);

        vec3 norm = normalize(Normal);
        // Combine lighting from both lights
        vec3 light1 = CalculateLight(lightPos1, lightColor1, norm, FragPos, viewPos);
        vec3 light2 = CalculateLight(lightPos2, lightColor2, norm, FragPos, viewPos);
        vec3 result = (ambient + light1 + light2) * objectColor;

        // Reflection component
        vec3 I = normalize(viewPos - FragPos);
        vec3 R = reflect(I, norm);
        vec4 reflectedColor = texture(texture1, R.xy * 0.5 + 0.5);
        vec3 reflection = reflectivity * vec3(reflectedColor);

        FragColor = texture(texture1, TexCoord) * vec4(result + reflection, 1.0);
    }
)";




// Set light properties
glm::vec3 lightPos(-1.0f, 1.0f, -1.0f); // Light position: top-left
glm::vec3 lightColor(1.0f, 1.0f, 1.0f); // White light
glm::vec3 objectColor(1.0f, 0.5f, 0.31f); // Adjust object color as needed

// Define the properties of the second light source
glm::vec3 lightPos2(1.0f, 1.0f, 1.0f); // Position of second light: top-right
glm::vec3 lightColor2(1.0f, 1.0f, 1.0f); // White color for the second light

const float width = 1.0f;  // Width of the case (x-axis)
const float height = 0.6f; // Height of the case (y-axis)
const float depth = 0.4f;  // Depth of the case (z-axis)

// Function to generate the vertices and indices for an elongated pyramid
void generateElongatedPyramidData(std::vector<float>& vertices, std::vector<unsigned int>& indices, float baseWidth, float baseDepth, float height) {
    // Calculate half dimensions to center the pyramid at the origin
    float halfWidth = baseWidth / 2.0f;
    float halfDepth = baseDepth / 2.0f;

    // Base vertices
    std::vector<glm::vec3> baseVertices = {
        glm::vec3(-halfWidth, 0.0f, halfDepth),
        glm::vec3(halfWidth, 0.0f, halfDepth),
        glm::vec3(halfWidth, 0.0f, -halfDepth),
        glm::vec3(-halfWidth, 0.0f, -halfDepth)
    };

    // Apex of the pyramid
    glm::vec3 apex = glm::vec3(0.0f, height, 0.0f);

    // Base vertices (duplicated for each triangle)
    for (int i = 0; i < 4; ++i) {
        // Position
        vertices.push_back(baseVertices[i].x);
        vertices.push_back(baseVertices[i].y);
        vertices.push_back(baseVertices[i].z);
        // Normals (downward for base)
        vertices.push_back(0.0f);
        vertices.push_back(-1.0f);
        vertices.push_back(0.0f);
        // Texture coordinates (arbitrary for base)
        vertices.push_back(0.0f); // u
        vertices.push_back(0.0f); // v
    }

    // Apex vertex (duplicated for each triangle)
    for (int i = 0; i < 4; ++i) {
        // Position
        vertices.push_back(apex.x);
        vertices.push_back(apex.y);
        vertices.push_back(apex.z);
        // Normals (will be recalculated for sides)
        vertices.push_back(0.0f);
        vertices.push_back(1.0f);
        vertices.push_back(0.0f);
        // Texture coordinates (arbitrary for apex)
        vertices.push_back(0.5f); // u
        vertices.push_back(1.0f); // v
    }

    // Base indices
    indices = {
        0, 1, 2,
        0, 2, 3
    };

    // Side indices
    int apexIndex = 4; // The index of the apex vertex
    for (int i = 0; i < 4; ++i) {
        int baseIndex = i;
        int nextBaseIndex = (i + 1) % 4;
        int sideApexIndex = 4 + i; // Offset by 4 to account for base vertices
        indices.push_back(baseIndex);
        indices.push_back(nextBaseIndex);
        indices.push_back(sideApexIndex);
    }
}


// Function to generate the vertices and indices for a cylinder
void generateCylinderData(std::vector<float>& vertices, std::vector<unsigned int>& indices, float height, float radius) {
    for (int i = 0; i < NUM_SEGMENTS; ++i) {
        float theta = 2.0f * M_PI * float(i) / float(NUM_SEGMENTS);
        float x = radius * cosf(theta); // X coordinate
        float z = radius * sinf(theta); // Z coordinate
        float u = float(i) / float(NUM_SEGMENTS); // Texture coordinate

        // Calculate normals for the sides
        glm::vec3 sideNormal = glm::normalize(glm::vec3(x, 0.0, z));

        // Top circle vertex position, texture coordinate, and normal
        vertices.push_back(x); // x
        vertices.push_back(height); // y (top of the cylinder)
        vertices.push_back(z); // z
        vertices.push_back(u); // Texture u
        vertices.push_back(1.0f); // Texture v (top)
        vertices.insert(vertices.end(), { sideNormal.x, sideNormal.y, sideNormal.z });

        // Bottom circle vertex position, texture coordinate, and normal
        vertices.push_back(x); // x
        vertices.push_back(0.0f); // y (bottom of the cylinder)
        vertices.push_back(z); // z
        vertices.push_back(u); // Texture u
        vertices.push_back(0.0f); // Texture v (bottom)
        vertices.insert(vertices.end(), { sideNormal.x, sideNormal.y, sideNormal.z });
    }

    // Indices for top and bottom circle
    for (int i = 0; i < NUM_SEGMENTS; ++i) {
        int nextIndex = (i + 1) % NUM_SEGMENTS;
        indices.push_back(i * 2);
        indices.push_back(nextIndex * 2);
        indices.push_back(NUM_SEGMENTS * 2); // Top center vertex

        indices.push_back(i * 2 + 1);
        indices.push_back(nextIndex * 2 + 1);
        indices.push_back(NUM_SEGMENTS * 2 + 1); // Bottom center vertex
    }

    // Center vertex for top and bottom circle
    vertices.insert(vertices.end(), { 0.0f, height, 0.0f, 0.5f, 1.0f, 0.0f, 1.0f, 0.0f }); // Top center normal
    vertices.insert(vertices.end(), { 0.0f, 0.0f, 0.0f, 0.5f, 0.0f, 0.0f, -1.0f, 0.0f }); // Bottom center normal

    // Indices for the sides of the cylinder
    for (int i = 0; i < NUM_SEGMENTS; ++i) {
        int nextIndex = (i + 1) % NUM_SEGMENTS;
        indices.push_back(i * 2);
        indices.push_back(nextIndex * 2);
        indices.push_back(i * 2 + 1);

        indices.push_back(nextIndex * 2);
        indices.push_back(nextIndex * 2 + 1);
        indices.push_back(i * 2 + 1);
    }
}


// Function to generate the vertices and indices for a plane
void generatePlaneData(std::vector<float>& vertices, std::vector<unsigned int>& indices, float width, float depth) {
    // Calculate half dimensions to center the plane at the origin
    float halfWidth = width / 2.0f;
    float halfDepth = depth / 2.0f;

    // Vertex data: position (x, y, z), texture coordinates (s, t)
    vertices = {
        // Positions          // Texture Coords (s, t)
        -halfWidth, 0.0f, -halfDepth,  0.0f, 0.0f, // Bottom left
         halfWidth, 0.0f, -halfDepth,  1.0f, 0.0f, // Bottom right
         halfWidth, 0.0f,  halfDepth,  1.0f, 1.0f, // Top right
        -halfWidth, 0.0f,  halfDepth,  0.0f, 1.0f, // Top left
    };

    indices = {
        0, 1, 2, // First triangle
        0, 2, 3  // Second triangle
    };
}




// Camera variables
glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
float deltaTime = 0.0f; // Time between current frame and last frame
float lastFrame = 0.0f; // Time of last frame
bool perspective = true; // Toggle between perspective and orthographic
float cameraSpeedMultiplier = 2.5f;

// Mouse control variables
float lastX = SCR_WIDTH / 2.0f;
float lastY = SCR_HEIGHT / 2.0f;
bool firstMouse = true;
float yaw = -90.0f; // Yaw is initialized to -90.0 degrees
float pitch = 0.0f;
float fov = 45.0f;


void processInput(GLFWwindow* window) {
    float currentFrame = glfwGetTime();
    deltaTime = currentFrame - lastFrame;
    lastFrame = currentFrame;
    float cameraSpeed = cameraSpeedMultiplier * deltaTime;

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraUp;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraUp;

    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        perspective = !perspective;
}

void mouse_callback(GLFWwindow* window, double xpos, double ypos) {
    if (firstMouse) {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos;
    lastX = xpos;
    lastY = ypos;

    float sensitivity = 0.1f;
    xoffset *= sensitivity;
    yoffset *= sensitivity;

    yaw += xoffset;
    pitch += yoffset;

    if (pitch > 89.0f)
        pitch = 89.0f;
    if (pitch < -89.0f)
        pitch = -89.0f;

    glm::vec3 front;
    front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    front.y = sin(glm::radians(pitch));
    front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(front);
}

void scroll_callback(GLFWwindow* window, double xoffset, double yoffset) {
    cameraSpeedMultiplier += (float)yoffset;
    if (cameraSpeedMultiplier < 1.0f)
        cameraSpeedMultiplier = 1.0f;
    if (cameraSpeedMultiplier > 10.0f)
        cameraSpeedMultiplier = 10.0f;
}


int main() {
    // Initialize GLFW
    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        return -1;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    // Create a windowed mode window and its OpenGL context
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "OpenGL Cylinder", NULL, NULL);
    if (!window) {
        std::cerr << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, [](GLFWwindow* window, int width, int height) {
        glViewport(0, 0, width, height);
        });

    // Set mouse and scroll callbacks
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);

    // Load OpenGL function pointers
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cerr << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    // Compile and link shaders
    unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
    glCompileShader(vertexShader);

    int success;
    char infoLog[512];
    glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;
    }

    unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
    glCompileShader(fragmentShader);

    glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;
    }

    unsigned int shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);

    glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
    if (!success) {
        glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
    }

    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    // Generate elongated pyramid data
    std::vector<float> pyramidVertices;
    std::vector<unsigned int> pyramidIndices;
    float pyramidBaseWidth = 1.0f; // Set the base width of the pyramid
    float pyramidBaseDepth = 0.5f; // Set the base depth of the pyramid
    float pyramidHeight = 0.8f; // Set the height of the pyramid
    generateElongatedPyramidData(pyramidVertices, pyramidIndices, pyramidBaseWidth, pyramidBaseDepth, pyramidHeight);

    // Create buffers for the elongated pyramid
    unsigned int pyramidVBO, pyramidVAO, pyramidEBO;
    glGenVertexArrays(1, &pyramidVAO);
    glGenBuffers(1, &pyramidVBO);
    glGenBuffers(1, &pyramidEBO);

    glBindVertexArray(pyramidVAO);

    glBindBuffer(GL_ARRAY_BUFFER, pyramidVBO);
    glBufferData(GL_ARRAY_BUFFER, pyramidVertices.size() * sizeof(float), &pyramidVertices[0], GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, pyramidEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, pyramidIndices.size() * sizeof(unsigned int), &pyramidIndices[0], GL_STATIC_DRAW);

    // Position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // Normal attribute
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(2);
    // Texture coordinate attribute
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);


    // Generate cylinder data
    std::vector<float> vertices;
    std::vector<unsigned int> indices;
    float cylinderHeight = 1.0f; // Set the height of the cylinder
    float cylinderRadius = 0.5f; // Set the radius of the cylinder
    generateCylinderData(vertices, indices, cylinderHeight, cylinderRadius);

    // Generate plane data
    std::vector<float> planeVertices;
    std::vector<unsigned int> planeIndices;
    float planeWidth = 5.0f; // For example
    float planeDepth = 5.0f; // For example
    generatePlaneData(planeVertices, planeIndices, planeWidth, planeDepth);

    // Create buffers for the cylinder
    unsigned int VBO, VAO, EBO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), &vertices[0], GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), &indices[0], GL_STATIC_DRAW);

    // Vertex attribute setup for the cylinder
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0); // Position
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float))); // Texture Coordinates
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(5 * sizeof(float))); // Normals
    glEnableVertexAttribArray(2);

    // Unbind VAO
    glBindVertexArray(0);

    unsigned int planeVAO, planeVBO, planeEBO;
    glGenVertexArrays(1, &planeVAO);
    glGenBuffers(1, &planeVBO);
    glGenBuffers(1, &planeEBO);

    // Plane VAO setup
    glBindVertexArray(planeVAO);

    glBindBuffer(GL_ARRAY_BUFFER, planeVBO);
    glBufferData(GL_ARRAY_BUFFER, planeVertices.size() * sizeof(float), planeVertices.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, planeEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, planeIndices.size() * sizeof(unsigned int), planeIndices.data(), GL_STATIC_DRAW);

    // Position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // Texture coordinate attribute
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);



    // Use shader program
    glUseProgram(shaderProgram);

    // Enable depth testing
    glEnable(GL_DEPTH_TEST);

    // Setup projection matrix
    glm::mat4 projection = glm::perspective(glm::radians(45.0f), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
    unsigned int projLoc = glGetUniformLocation(shaderProgram, "projection");
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, &projection[0][0]);

    // Load and create the texture
    unsigned int texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);

    // Set texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    // Set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // Load image, create texture and generate mipmaps
    int width, height, nrChannels;
    stbi_set_flip_vertically_on_load(true); // Flip the image as OpenGL expects the 0.0 coordinate on the y-axis to be on the bottom side
    unsigned char* data = stbi_load("C:\\Users\\Bulle\\OneDrive\\Desktop\\Marble.jpg", &width, &height, &nrChannels, 0);

    if (data) {
        // The format of the image depends on the number of channels it has
        GLenum format = GL_RGB;
        if (nrChannels == 4)
            format = GL_RGBA;

        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else {
        std::cerr << "Failed to load texture" << std::endl;
    }

    stbi_image_free(data);



    // Load and create the texture for the plane
    unsigned int planeTexture;
    glGenTextures(1, &planeTexture);
    glBindTexture(GL_TEXTURE_2D, planeTexture);

    // Set texture wrapping and filtering options
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // Reuse previously defined variables for width, height, and nrChannels
    data = stbi_load("C:\\Users\\Bulle\\OneDrive\\Desktop\\wood.jpg", &width, &height, &nrChannels, 0);
    if (data) {
        GLenum format = GL_RGB;
        if (nrChannels == 4) {
            format = GL_RGBA;
        }
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else {
        std::cerr << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);;


    // Render loop
    while (!glfwWindowShouldClose(window)) {
        // Clear the color and depth buffers
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glUniform3fv(glGetUniformLocation(shaderProgram, "lightPos"), 1, &lightPos[0]);
        glUniform3fv(glGetUniformLocation(shaderProgram, "viewPos"), 1, &cameraPos[0]);
        glUniform3fv(glGetUniformLocation(shaderProgram, "lightColor"), 1, &lightColor[0]);
        glUniform3fv(glGetUniformLocation(shaderProgram, "objectColor"), 1, &objectColor[0]);
        glUniform3fv(glGetUniformLocation(shaderProgram, "lightPos2"), 1, &lightPos2[0]);
        glUniform3fv(glGetUniformLocation(shaderProgram, "lightColor2"), 1, &lightColor2[0]);

        // Process keyboard input
        processInput(window);

        // Update the projection matrix based on the 'perspective' variable
        glm::mat4 projection;
        if (perspective) {
            projection = glm::perspective(glm::radians(45.0f), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
        }
        else {
            float orthoSize = 5.0f;
            projection = glm::ortho(-orthoSize, orthoSize, -orthoSize, orthoSize, 0.1f, 100.0f);
        }
        unsigned int projLoc = glGetUniformLocation(shaderProgram, "projection");
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, &projection[0][0]);

        // Update the view matrix based on the camera's position and orientation
        glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        unsigned int viewLoc = glGetUniformLocation(shaderProgram, "view");
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, &view[0][0]);

        // Bind the texture
        glBindTexture(GL_TEXTURE_2D, texture);

        // Calculate the model matrix for the cylinder
        glm::mat4 model = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(0.0f, -0.2f, 0.0f)); // Center the cylinder on the screen
        model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f)); // Scale if needed
        unsigned int modelLoc = glGetUniformLocation(shaderProgram, "model");
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, &model[0][0]);

        // Render the cylinder
        glBindVertexArray(VAO);
        glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);

        // Render the plane
        glBindTexture(GL_TEXTURE_2D, planeTexture); // White texture for the plane
        glm::mat4 planeModel = glm::mat4(1.0f);
        planeModel = glm::translate(planeModel, glm::vec3(0.0f, 0.0f, 0.0f)); // Position the plane below the cylinder
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, &planeModel[0][0]);

        glBindVertexArray(planeVAO);
        glDrawElements(GL_TRIANGLES, planeIndices.size(), GL_UNSIGNED_INT, 0);

        // Calculate the model matrix for the pyramid
        glm::mat4 pyramidModel = glm::mat4(1.0f);
        float offset = planeWidth / 2.0f - pyramidBaseWidth / 2.0f;
        pyramidModel = glm::translate(pyramidModel, glm::vec3(-offset, -pyramidHeight / 2.0f, 0.0f)); // Adjust position as needed
        // Add a rotation around the y-axis
        pyramidModel = glm::rotate(pyramidModel, glm::radians(90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        pyramidModel = glm::scale(pyramidModel, glm::vec3(1.0f, 1.0f, 3.0f)); // Scale if needed



        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, &pyramidModel[0][0]);






        // Render the pyramid
        glBindVertexArray(pyramidVAO);
        glDrawElements(GL_TRIANGLES, pyramidIndices.size(), GL_UNSIGNED_INT, 0);


        // Swap buffers and poll IO events
        glfwSwapBuffers(window);
        glfwPollEvents();
    }



    // Deallocate all resources once they've outlived their purpose
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);

    // Terminate GLFW, clearing any resources allocated by GLFW.
    glfwTerminate();

    return 0;
}
